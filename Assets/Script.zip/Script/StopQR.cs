using Microsoft.MixedReality.QR;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StopQR : MonoBehaviour
{
    private static GameObject QRCode;

    // Start is called before the first frame update
    void Start()
    {


    }

    public void stopQrcode_detection()
    {

    }

}
